Actual mod is located in Mod folder; only the contents of this folder should be added to the Minecraft jar.

To install, create a new profile named TMCWv4 with 1.6.4 as the version and click Play to download it (or
copy an existing 1.6.4 installation), then go to the versions folder in .minecraft (%appdata% on Windows)
and rename the folder and jar to TMCWv4. Replace the json file with the one found in the root of this archive;
it has already been modified so the launcher will not try to redownload the jar. Install the mod files directly
into the jar using a zip utility (do not try to rename it to zip and use Windows because there is a class
file in the vanilla jar with a reserved Windows filename which will break things), and delete META-INF (if
you want to install Optifine install it the same way; do not use its installer. There are no conflicting
classes and the order should not matter but I installed TMCWv4 afterwards; the only known conflict is the
complete lack of void fog in TMCW, which Optifine cannot restore because I changed a different class).

Also, I recommend the following JVM arguments:

-Xmx512M -XX:+UseConcMarkSweepGC -XX:-UseAdaptiveSizePolicy -Xmn128M -Xss1024K

512 MB is more than enough as TMCW is very lightweight, even less demanding than vanilla, and allocating more
memory than needed slows things down; you also do not need the fancy arguments that modern versions need due to
their insane demands on the JVM due to rampant object allocation and terribly optimized code.

See https://web.archive.org/web/20130819173020/http://help.mojang.com/customer/portal/articles/325948-minecraft-system-requirements
for the system requirements for 1.6, which still apply to TMCW.

NoExclusion contains classes modified to remove the near-origin exclusion zone for caves, ravines, and
mineshafts; strongholds are not affected (near-origin is within a 32 chunk circular radius for most caves,
40 chunks for colossal cave systems and within 32 chunks of any corner for regional caves. Mineshafts are
normally limited in size within this area, otherwise their frequency is the same). These are to be added
after the other mod files.

CustomSkin is a resource pack (does not have to be zipped, just drop into resource pack folder) which makes it
easier to add a custom skin (mine is included as an example) since the skin server used by 1.6.4 no longer works
(https://bugs.mojang.com/browse/WEB-985). The mod itself also includes my own skin in place of the default skin.
You can also edit an existing resource pack by adding/replacing "assets\minecraft\textures\entity\steve.png";
note that it must use the old skin format (64x32).

AMIDST contains classes that are to be added to the Minecraft jar (by themselves, not as part of the mod) so
AMIDST (tested with up to AMIDST 4.2) can be used to map out land/ocean/climate zones (no biome information
is displayed since unknown biomes crash AMIDST and/or do not display correctly). When modifying Minecraft jar
only META-INF needs to be deleted; the version does not need to be run in the launcher (it is a good idea to
rename it though so you know what it is). Climate zones are displayed as plains = normal, desert = hot, ice
plains = cold, with small islands of forest having nearly any biome and mushroom islands being the same as
in-game. Note that the spawn point and locations of structures are not correct (AMIDST does not read the jar
for these, it is hard-coded into AMIDST).

CaveFinder is a standalone Java app that gives the locations of most underground features (caves, ravines,
mineshafts, and strongholds), including listing the largest caves/ravines/mineshafts by size and distance, as well
as having the ability to generate maps of most underground features. This program can be run without a system Java
installation by modifying the provided batch file to point to the location of the Java runtime, located at 
"C:\Program Files (x86)\Minecraft\runtime\jre-x64\bin\java.exe" (64 bit; 32 bit excludes (x86) and has x32 instead
of x64; include the quotes when pasting the path into the batch file). Also, the buffer size for the console window
should also be set to at least 300 (for 10 results) to ensure that all of the output can be seen (right-click on
title bar, properties, layout).

MLG contains a modified version of ChunkProviderGenerate which creates a Superflat-like world with only caves
and structures, which is to be added to the Minecraft server jar* after adding the other mod files (excluding
the net and assets folders; it can also be used on the client with the normal mod) so you can use Minecraft
Land Generator to quickly generate terrain (taking a few seconds or less per 380x380 block increment), then
use a utility like Unmined to view caves.

*While TMCW can be added to the server jar it is unlikely to work properly if you try to play on the server
since there are several interactions between the client and (internal) server.

Minutor contains definition files for blocks and biomes; note that in order to work properly any other
definition files must be later in alphabetical order (TMCW biomes do not correspond to vanilla 1.7+ biomes,
same for blocks).